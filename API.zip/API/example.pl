use Barracuda::Rest::API;
use Data::Dumper;

my $API = Barracuda::Rest::API->new('specify_unit_ip', '8000', 'v2', 'http', 'no');

# Require user to login at initial step
$API->login("admin", "admin");
my $result;
# Creating a Resource
print "Creating Resources\n";

# Create a Virtual Service
print "Creating Virtual Service\n";
$result = $API->create('virtual_services', {virtual_service_group_id => 'default'}, { name => "v6test", ip_address => "192.168.17.125", port => "80", type => "http", address_version => "ipv4", netmask => "255.255.255.0", interface => "ge-1-1" } );
print Dumper($result);

# Create a Server
print "Creating Server\n";
$result = $API->create('servers', { virtual_service_group_id => 'default', virtual_service_id => "v6test"}, { name => "Server_12.0.0.128", address_version => "ipv4", ip_address => "12.0.0.128", port => 80, identifier => "ipaddr"});
print Dumper($result);

# Craete a content rule
print "Creating Content Rule\n";
$result = $API->create('content_rules', { virtual_service_group_id => 'default', virtual_service_id => "v6test"}, { name => "rule9000", host_match => "*.barracuda.com", url_match => "/*", extended_match => "*", extended_match_sequence => 5});
print Dumper($result);


# Create a monitor group
print "Creating Monitor Group\n";
$result = $API->create('monitor_groups', undef, { "name" => "MS_IIS App Pool Monitor"} );
print Dumper($result);


# Add a monitor to the group
print "Creating monitor\n";
$result = $API->create('monitors', { monitor_group_id => "MS_IIS App Pool Monitor" }, { name => "Exchange-Owa-Monitor", type => "NTLMS_TEST", address_version => "ipv4", ip_address => "192.23.2.2", delay => 30, username => "owq", password => "msft", target => "http://barracuda.com", match => "/barracuda", headers => "", status_code => 200, port => "80" } );
print Dumper($result);

# Listing a Resource
print "Listing Resources\n";
# Listing Virtual Services
print "Listing Virtual Services\n";
$result = $API->list('virtual_services', { virtual_service_group_id => 'default' });
print Dumper($result);

# Listing Servers
print "Listing Servers\n";
$result = $API->list('servers', { virtual_service_group_id => 'default', virtual_service_id => "v6test"});
print Dumper($result);

# Listing Content Rules
print "Listing Content Rules\n";
$result = $API->list('content_rules', { virtual_service_group_id => 'default',  virtual_service_id => "v6test"});
print Dumper($result);

# Listing Monitor Groups
print "Listing Monitor Groups\n";
$result = $API->list('monitor_groups');
print Dumper($result);

# Listing Monitors
print "Listing Monitors\n";
$result = $API->list('monitors', { monitor_group_id => "MS_IIS App Pool Monitor"});
print Dumper($result);

# Retrieving a Resource
print "Retrieving Resources\n";
# Retrieve a Virtual Service
print "Retrieving Virtual Service\n";
$result = $API->get('virtual_services', {virtual_service_group_id => 'default', id => "v6test"});
print Dumper($result);

# Retrieve a Server
print "Retrieving Server\n";
$result = $API->get('servers', {virtual_service_group_id => 'default', virtual_service_id => "v6test", id => "Server_12.0.0.128"});
print Dumper($result);

# Retrieve a Content Rule
print "Retrieving Content Rule\n";
$result = $API->get('content_rules', {virtual_service_group_id => 'default', virtual_service_id => "v6test", id => "rule9000"});
print Dumper($result);

# Retrieve a Monitor Group
print "Retrieve Monitor Group\n";
$result = $API->get('monitor_groups');
print Dumper($result);

# Retrieve a Monitor
print "Retrieve Monitor\n";
$result = $API->get('monitors', { id => "Exchange-Owa-Monitor", monitor_group_id => "MS_IIS App Pool Monitor"});
print Dumper($result);

# Update Resource
print "Updating Resources\n";
# Update a Virtual Service
print "Updating Virtual Service\n";
$result = $API->update('virtual_services', {virtual_service_group_id => 'default', id => "v6test"}, { enable => 0 } );
print Dumper($result);

# Update a Server
print "Updating Servers\n";
$result = $API->update('servers', {virtual_service_group_id => 'default', virtual_service_id => "v6test", id => "Server_12.0.0.128"},{ status => "maintenance" } );
print Dumper($result);

# Update a Content Rule
print "Updating Content Rule\n"
$result = $API->update('content_rules', {virtual_service_group_id => 'default', virtual_service_id => "v6test", id => "rule9000"}, { host_match => "*.changeit.com" } );
print Dumper($result);

# Update a Monitor
print "Updating Monitors\n";
$result = $API->update('monitors', { id => "Exchange-Owa-Monitor", monitor_group_id => "MS_IIS App Pool Monitor"},{ ip_address => "192.1.1.1" } );
print Dumper($result);

# Deleting Resources
print "Deleting Resources\n";
# Remove a Monitor
print "Removing Monitors\n";
$result = $API->remove('monitors', { monitor_group_id => "MS_IIS App Pool Monitor", id => "Exchange-Owa-Monitor"} );
print Dumper($result);

# Remove a Monitor Group
print "Removing Monitor Groups\n";
$result = $API->remove('monitor_groups', {id => "MS_IIS App Pool Monitor"} );
print Dumper($result);

# Remove a Content Rule
print "Removing Content Rules\n";
$result = $API->remove('content_rules', {virtual_service_group_id => 'default', virtual_service_id => "v6test", id => "rule9000"} );
print Dumper($result);

# Remove a Server
print "Removing Servers\n";
$result = $API->remove('servers', {virtual_service_group_id => 'default', virtual_service_id => "v6test", id => "Server_12.0.0.128"});
print Dumper($result);

# Remove a Virtual Service
print "Removing Virtual Services";
$result = $API->remove('virtual_services', {virtual_service_group_id => 'default', id => "v6test"});
print Dumper($result);

package Barracuda::Rest::API;

#use 5.014002;
use warnings;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use Barracuda::Rest::API ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
#our %EXPORT_TAGS = ( 'all' => [ qw(

#) ] );

#our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

#our @EXPORT = qw(

#);

our $VERSION = '0.01';


# Preloaded methods go here.
use WWW::Curl::Easy;
use WWW::Curl::Form;
use JSON::XS;

# Specify the supported resources
my $supported_objects = { 'virtual_service_groups' => 1,
      'virtual_services' => 1,
      'servers' => 1,
      'content_rules' => 1,
      'monitor_groups' => 1,
      'monitors' => 1,
      'rg_servers' => 1,
      'security_policies' => 1,
      'data_theft_protections' => 1,
      'global_acls' => 1,
      'attack_groups' => 1,
      'actions' => 1,
      'certificates' => 1
};

my $require_multipart = {
  'certificates' => 1
};

# create the URI based on the resource, id and options
sub __construct_uri {
  my $self = shift;
  my $resource = shift;
  my $ids = shift;
  my $options = shift;
  my $uri;

  if ( $resource eq "virtual_service_groups" || $resource eq "monitor_groups"|| $resource eq "certificates" || $resource eq "security_policies" ) {
    $uri = "/$resource";
  } elsif ( $resource eq "virtual_services" ) {
    if ( $self->{_version} eq "v2" ) {
      die "virtual_service_group_id required." unless exists($ids->{virtual_service_group_id});
      $uri = "/virtual_service_groups/" . $ids->{virtual_service_group_id}; 
    }
    $uri .= "/$resource";
  } elsif ( $resource eq "servers" || $resource eq "content_rules" ) {
    die "virtual_serice_id required."  unless exists($ids->{virtual_service_id});
    if ( $self->{_version} eq "v2" ) {
      die "virtual_service_group_id required." unless exists($ids->{virtual_service_group_id});
      $uri = "/virtual_service_groups/" . $ids->{virtual_service_group_id};
    }
    $uri .= "/virtual_services/" . $ids->{virtual_service_id} . "/$resource";   
  } elsif ( $resource eq "rg_servers" ) {
    die "virtual_service_id required." unless exists($ids->{virtual_service_id});
    die "content_rule_id required." unless exists($ids->{content_rule_id});
    die "virtual_service_group_id required." unless exists($ids->{virtual_service_group_id});
    $uri = "/virtual_service_groups/" . $ids->{virtual_service_group_id}; 
    $uri .= "/virtual_services/" . $ids->{virtual_service_id} . "/content_rules/" . $ids->{content_rule_id}. "/$resource";
  } elsif ( $resource eq "monitors") {
    $uri = "/monitor_groups/" . $ids->{monitor_group_id} . "/$resource";
  } elsif ($resource eq "data_theft_protections" || $resource eq "global_acls" || $resource eq "attack_groups") {
    die "policy_id required." unless exists($ids->{policy_id});
    $uri = "/security_policies/" . $ids->{policy_id} . "/$resource";
  } elsif ($resource eq "actions"){
    die "attack_group_id required" unless exists($ids->{attack_group_id});
    die "policy_id required" unless exists($ids->{policy_id});
    $uri = "/security_policies/" . $ids->{policy_id} . "/attack_groups/" . $ids->{attack_group_id} . "/$resource";
  } else {
    die "Invalid object name";
  }

  $uri .= "/" . $ids->{id} if exists($ids->{id});

  # Handle optional fields
  if($options) {
    $uri .= "?";
    foreach my $option (keys %$options) {
      $uri .= $option . "=" . $options->{$option} . "&";
    }
    chop($uri); # remove the trailing '&'
  }
  return $uri;
}

# make the request to the ADC box using WWW::Curl::Easy
sub __request {
  my $self = shift;
  my $type = uc(shift); # POST, GET, PUT, DELETE
  my $uri = shift;
  my $data = shift;
  my $req_multipart = shift || 0;

  my $curl = WWW::Curl::Easy->new;
  my $decoder = new JSON::XS->allow_nonref(1);

  my $data_encoded;
  if ( $data && !$req_multipart ) {
    $data_encoded = encode_json($data);
  }
  my $response_body;
  $curl->setopt(CURLOPT_HEADER,1);
  if ( $req_multipart ) {
    $curl->setopt(CURLOPT_HTTPHEADER, ['Content-Type:multipart/form-data']);
  } else {
    $curl->setopt(CURLOPT_HTTPHEADER, ['Content-Type:application/json']);
  }
  $curl->setopt(CURLOPT_USERPWD, $self->{_token});
  $curl->setopt(CURLOPT_URL, $self->{_url}. $uri);
  if ( $self->{_type}  eq "https") {
    if ( $self->{_cacert_verify} eq 'yes' ) {
      $curl->setopt(CURLOPT_SSL_VERIFYPEER, 1);
      $curl->setopt(CURLOPT_CAINFO, $self->{_cacert});
    } else {
      $curl->setopt(CURLOPT_SSL_VERIFYPEER, 0);
    }
  }

  if($type eq "POST") {
    $curl->setopt(CURLOPT_POST, 1);
    if ( $req_multipart ) {
      $curl->setopt(CURLOPT_HTTPPOST, $data);
    } else {
      $curl->setopt(CURLOPT_POSTFIELDS, $data_encoded);
    }
  } elsif ( $type eq "GET" ) {
    # Do nothing for GET request

  } elsif ( $type eq "PUT" ) {
                $curl->setopt(CURLOPT_CUSTOMREQUEST, 'PUT');
                $curl->setopt(CURLOPT_POSTFIELDS, $data_encoded);

  } elsif ( $type eq "DELETE" ) {
    $curl->setopt(CURLOPT_CUSTOMREQUEST, 'DELETE');
  } else {
    die "Invalid Request Type";
  }

  $curl->setopt(CURLOPT_WRITEDATA,\$response_body);
  # Starts the actual request
  my $retcode = $curl->perform;


  if ($retcode == 0) {
          #Transfer went ok
          my $response_code = $curl->getinfo(CURLINFO_HTTP_CODE);
          # judge result and next action based on $response_code

          # Seperate the headers and body information
          my $header_size = $curl->getinfo(CURLINFO_HEADER_SIZE);
          my ($header, $body) = (substr($response_body, 0 , $header_size) , substr($response_body,$header_size) );
          # Get body as a hash to be able to use it.
          $body = $decoder->decode($body);
          $self->{_token} = $body->{token} if exists($body->{token});
          return $body;
  } else {
                # Error code, type of error, error message
                 return {error => { msg => "Could not complete request."}};
                #die("An error happened: $retcode ".$curl->strerror($retcode)." ".$curl->errbuf."\n");

  }

}

sub __create_multiform_data {
  my $form_data = shift;
  my $files = shift;
  my $data = shift;

  my $curlf = WWW::Curl::Form->new;
  foreach my $param ( @$form_data ) {
    if ( exists( $data->{$param} ) ) {
      $curlf->formadd($param, $data->{$param});
    }
  }
  foreach my $file ( @$files ) {
    if ( exists( $data->{$file} ) ) {
      $curlf->formaddfile($data->{$file}, $file, "multipart/form-data");
    }
  }
 
  return $curlf; 
}

sub __certificates {
  my $data = shift;
  my $options = shift;
 
  return ( $data, 0 ) if (!$options);
 
  if ( $options->{upload} eq "signed" ) {
    my $form_data = ['name', 'type', 'password', 'assign_associated_key', 'allow_private_key_export'];
    my $files = ['signed_certificate', 'key'];
   
    my $curlf = __create_multiform_data($form_data, $files, $data); 
    
    my $iter = 0;
    my $intermediary_cert = 'intermediary_certificate_';
    my $match = $intermediary_cert.$iter;
    while ( $data->{$match} ) {
      $curlf->formaddfile($data->{$match}, $match, "multipart/form-data");
      $iter++;
      $match = $intermediary_cert.$iter;
    } 
    return ($curlf, 1); 
  } elsif ( $options->{upload} eq "trusted" ) {
    my $form_data = ['name'];
    my $files = ['trusted_certificate'];
    my $curlf = __create_multiform_data($form_data, $files, $data);
    
    return($curlf, 1);
  }   
  
  return ($data, 0); 
}


# create the uri and execute the API
sub __handle_request {
  my $request_type = shift;
  my $self = shift;
  my $resource = shift;
  my $ids = shift;
  my $data = shift;
  my $options = shift || undef;
  return { error => { msg => "Unsupported specified object $resource"} } unless $supported_objects->{$resource};

  my $uri = $self->__construct_uri($resource, $ids, $options);
  return { error => { msg => "Sorry an error occured while constructing the uri" } } unless $uri;


  my $multipartForm = ( $require_multipart->{$resource} ) ? 1 : 0;
  if ( $multipartForm ) { 
    no strict 'refs';
    my $method = "__$resource";
    # method will return the updated date or the same and specify that we are not using multipartForm data 
    ($data, $multipartForm) = &{$method}($data, $options);
  }
  return __request($self, $request_type, $uri, $data, $multipartForm);
}

sub new {
  my $class = shift;
  my $ip = shift;
  my $port = shift;
  my $version = shift;
  my $type = shift || undef;
  my $cacert_verify = shift || undef;
  die "Invalid cacert_verify parameter" if($cacert_verify && $cacert_verify ne 'yes' && $cacert_verify ne 'no');

  if( $type ) {
    $type = lc($type);
  }

  if ( $cacert_verify ) {
    $cacert_verify = lc($cacert_verify);
  }

  my $cacert = shift || undef;

  if ( $version ne "v1" && $version ne "v2" ) {
    die "Please specify valid version (v1, v2)";
  }

  my $self = { _ip_address => $ip,
      _port => $port,
      _type => $type,
      _url => $type.'://'.$ip.":".$port."/restapi/".$version,
      _cacert_verify => $cacert_verify,
      _cacert => $cacert,
      _token => undef,
      _version => $version,
      };

  my $ip_range = '([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])';
  if(!($self->{_ip_address} =~ /^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\.$ip_range\.$ip_range\.$ip_range$/)) {
    die "Invalid ip address";
  }

  if(!($self->{_port} >= 1 && $self->{_port} <= 65535)) {
    die "Invalid port number";
  }

  if($self->{_type} ne "http" && $self->{_type} ne "https") {
    die "Invalid request type";
  }

  if( defined($self->{_cacert_verify}) && $self->{_cacert_verify} eq 'yes') {
    if(!$self->{_cacert} || ($self->{_cacert} && !(-e $self->{_cacert}))) {
      die "Certficate cannnot be found";
    }
  }

  bless $self, $class;
  return $self;
}


sub login {
  my $self = shift;
  my $username = shift;
  my $password = shift;
  my $cred = {username => $username , password => $password};

  return __request($self, 'POST', '/login', $cred, undef);
}


sub logout {
  my $self = shift;
  return __request($self, 'DELETE', '/logout');
}


sub create {
  return __handle_request('POST', @_);
}

sub list {
  my $self = shift;
  my $resource = shift;
  my $ids = shift;
  my $options = shift;

  return __handle_request('GET', $self, $resource, $ids, undef, $options);
  #return __handle_request('GET', @_);
}

sub get {
  my $self = shift;
  my $resource = shift;
  my $ids = shift;
  my $options = shift;
  return __handle_request('GET', $self, $resource, $ids, undef, $options);
}

sub update {
  return __handle_request('PUT', @_);
}

sub remove {
  return __handle_request('DELETE', @_);
}

1;
__END__
=head1 NAME

Barracuda::Rest::API - Perl extension for Barracuda ADC Rest API

=head1 VERSION

Supported Version: 1

=head1 SYNOPSIS
  This module allows you to make request to the ADC Rest API. It creates a wrapper around WWW::Curl::Easy and constructs the curl operations for the user. This allows the user to focus more on their application and less on the details of the implementation.

=head2 EXAMPLE CODE

  use Barracuda::Rest::API;
  use Data::Dumper;

  my $api = Barracuda::Rest::API->new("[my ip address]", "[ port ]", '[ version ]', [ http | https], [ certificate verify boolean], [ certificate path ]);

  my $result;
  $result = $api->create('virtual_services', {virtual_service_group_id => 'default'}, {name => "v6test", ip_address => "192.168.17.125", port => "80", type => "http", address_version => "4", interface => "ge-1-1", netmask => "255.255.255.0"});

  $result = $api->create('servers', {virtual_service_group_id => 'default', virtual_service_id => "v6test"}, {name => "server9000", ip_address => "12.0.0.128", port => "80"} );

  $result = $api->create('content_rules', {virtual_service_group_id => 'default', virtual_service_id => "v6test"}, {name => "rule9000", host_match => "*.sdk.com", url_match => "/sdk", extended_match => "*", extended_match_sequence => "1000"} );

=head1 DESCRIPTION

This module provides several methods: new, login, logout, create, list, get, update, and remove. To start using the API, create a new object using the method "new". This will hold the ip address of the ADC Barracuda application along with the port and whether the transport will be over http and https. The next necessary step to take before any configuration changes can be made is the login phase. Upon successful authorization the create, list, get, update and remove methods should be available for use. After all configuration changes have been made, the logout method should be called to prevent any further changes.

=head1 AUTHOR

Barracuda Networks

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2013 by Barracuda Networks

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.14.2 or,
at your option, any later version of Perl 5 you may have available.

=head1 METHODS

=head2 new

  Title     : new
  Usage     : my $api = Barracuda::Rest::API->new($ip_address, $port, $version, $type, $cacert_verify, $cacert);
  Function  : retrieve the ADC rest API object with the initialized parameters
  Returns   : Rest API object to create request
  Args      : named arguments:
            : -ip_address => ip address of the ADC box
            : -port => port of the ADC box (8000, 443)
            : -versoin => api version ( v2 )
            : -type => http type (HTTP,  HTTPS)
            : -cacert_verify => Optional. Specify verification of CA certificate ('yes', 'no')
            : -cacert => Optional. Location of CA certificate for verification.



=head2 Login

  Title     : Login
  Usage     : $api->login($username, $password);
  Function  : retrieve the ADC rest API object with the initialized parameters
  Returns   : { token => "your_token"}
  Args      : named arguments:
            : -username => user name to the ADC appliance
            : -password => password to the ADC appliance


=head2 Logout

  Title     : Logout
  Usage     : $api->logout();
  Function  : log out of the ADC appliance.
  Returns   : { msg => "Successfully logged out!" }
  Args      : named arguments:


=head2 Create

  Title     : create
  Usage     : $api->create($resource, $ids, $data);
  Function  : create the specified resource
  Returns   : { {key value pairs of your resource parameters}, token => "new_token"}
  Args      : named arguments:
            : -resource => name of the resource (virtual_services, servers, etc...)
            : -ids => hash containing the parent ids
            : -data => hash of parameters required to create the specified object


=head2 List

  Title     : list
  Usage     : $api->list($resource, $ids, $options);
  Function  : list the specified resource
  Returns   : { object => "resource_name", fields => "field_specified", limits => "limit_specified", offset => "offset_specified", data => [ array of hashed objects specifed by resource ], token => "new_token"}
  Args      : named arguments:
            : -resource => name of the resource (virtual_services, servers, etc...)
            : -ids => hash containing the parent ids
            : -options => hash of options to limit output


=head2 Get

  Title     : get
  Usage     : $api->get($resource, $ids, $options);
  Function  : retrieve the specified resource
  Returns   : { { key value pairs of your resource parameters}, token => "new_token"}
  Args      : named arguments:
            : -resource => name of the resource (virtual_services, servers, etc...)
            : -ids => hash containing the parent ids and its own id
            : -options => hash of options to limit output


=head2 Update

  Title     : update
  Usage     : $api->update($resource, $ids, $data);
  Function  : update the specified resource
  Returns   : { { key value pairs of your resource parameters }, token => "new_token"}
  Args      : named arguments:
            : -resource => name of the resource (virtual_services, servers, etc...)
            : -ids => hash containing the parent ids and its own id
            : -data => hash of parameters to update the specified object


=head2 Remove

  Title     : remove
  Usage     : $api->remove($resource, $ids);
  Function  : delete the specified resource
  Returns   : { msg => "Successfully deleted", token => "new_token"}
  Args      : named arguments:
            : -resource => name of the resource (virtual_services, servers, etc...)
            : -ids => hash containing the parent ids and its own id



=cut

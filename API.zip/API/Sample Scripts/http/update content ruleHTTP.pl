#This Perl script assumes you have the REST API Perl module along it's required Perl modules installed. 
#
#What this script does: Generates a authentication token with the Barracuda Load Balancer ADC and updates a content rule with the specified settings.
#NOTE: CHANGE ALL PARAMETER VALUES PRIOR TO RUNNING THE SCRIPT 
#Author: Barracuda Networks

use Barracuda::Rest::API;
use Data::Dumper;

#Specify the Barracuda Load Balancer ADC Information here
my $API = Barracuda::Rest::API->new('<ADC_IP_ADDRESS>', '8000', 'v2', 'http', 'no'); 

#Login to the Barracuda Load Balancer ADC
$API->login("<USERNAME>", "<PASSWORD>"); #Enter login information here
my $result;

# Update a Content Rule
print "Updating Content Rule\n"
$result = $API->update('content_rules', {virtual_service_group_id => 'default', virtual_service_id => "v6test", id => "rule9000"}, { host_match => "*.changeit.com" } );
print Dumper($result);

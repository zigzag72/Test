#Barracuda Load Balancer ADC REST API Content Rule Demo.
#This Perl script assumes you have the REST API Perl module along it's required perl modules installed. Use this script to create a service and add a content rule to that service
#
#What this script does: Generates a authenication token with the Barracuda Load Balancer ADC, Creates a service called "demo_service", Creates a content rule called "rule1", and attaches a server called #"rule_server" to that content rule. 
#NOTE: CHANGE ALL PARAMETER VALUES PRIOR TO RUNNING THE SCRIPT 
#Author: Jeffrey Su Barracuda Networks

use Barracuda::Rest::API;
use Data::Dumper;

#Specify the Barracuda Load Balancer ADC Information here
my $API = Barracuda::Rest::API->new('<ADC_IP_ADDRESS>', '8000', 'v2', 'http', 'no'); 

#Login to the Barracuda Load Balancer ADC
$API->login("<USERNAME>", "<PASSWORD>"); #Enter login information here
my $result;

# Create a Virtual Service
print "Creating Virtual Service\n";
$result = $API->create('virtual_services', {virtual_service_group_id => 'default'}, { name => "demo_service", ip_address => "10.5.7.193", port => "80", type => "http", address_version => "ipv4", netmask => "255.255.255.0", interface => "ge-1-1" } );

# Craete a content rule
print "Creating Content Rule\n";
$result = $API->create('content_rules', { virtual_service_group_id => 'default', virtual_service_id => "demo_service"}, { name => "rule1", host_match => "*.barracuda.com", url_match => "/*", extended_match => "*", extended_match_sequence => 5});

#Add a server to the content rule
print "Adding a server to the content rule\n";
$result = $API->create('rg_servers', { virtual_service_group_id => 'default', virtual_service_id => "demo_service", content_rule_id => "rule1"}, { name => "rule_server", identifier => "ipaddr", ip_address => "10.5.7.185", port => "80"} );

#This Perl script assumes you have the REST API Perl module along it's required perl modules installed. 
#
#What this script does: Generates a authentication token with the Barracuda Load Balancer ADC, creates a monitor group, and adds a monitor to that group. 
#NOTE: CHANGE ALL PARAMETER VALUES PRIOR TO RUNNING THE SCRIPT 
#Author: Barracuda Networks

use Barracuda::Rest::API;
use Data::Dumper;

#Specify the Barracuda Load Balancer ADC Information here
my $API = Barracuda::Rest::API->new('<ADC_IP_ADDRESS>', '443', 'v2', 'https', '<Cacert_verify: true or false>', '<Certificate location>'); 

#Login to the Barracuda Load Balancer ADC
$API->login("<USERNAME>", "<PASSWORD>"); #Enter login information here
my $result;

# Create a monitor group
print "Creating Monitor Group\n";
$result = $API->create('monitor_groups', undef, { "name" => "MS_IIS App Pool Monitor"} );

# Add a monitor to the group
print "Creating monitor\n";
$result = $API->create('monitors', { monitor_group_id => "MS_IIS App Pool Monitor" }, { name => "Exchange-Owa-Monitor", type => "NTLMS_TEST", address_version => "ipv4", ip_address => "10.5.7.139", delay => 30, username => "owq", password => "msft", target => "http://barracuda.com", match => "/barracuda", headers => "", status_code => 200, port => "80" } );# Create a monitor group
print "Creating Monitor Group\n";
$result = $API->create('monitor_groups', undef, { "name" => "MS_IIS App Pool Monitor"} );
print Dumper($result);




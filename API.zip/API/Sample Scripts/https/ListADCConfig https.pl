#This Perl script assumes you have the REST API Perl module along it's required perl modules installed. 
#
#What this script does: Generates a authentication token with the Barracuda Load Balancer ADC and lists out all the services and rules configured on the ADC. 
#NOTE: CHANGE ALL PARAMETER VALUES PRIOR TO RUNNING THE SCRIPT 
#Author: Barracuda Networks

use Barracuda::Rest::API;
use Data::Dumper;

#Specify the Barracuda Load Balancer ADC Information here
my $API = Barracuda::Rest::API->new('<ADC_IP_ADDRESS>', '443', 'v2', 'https', '<Cacert_verify: true or false>', '<Certificate location>'); 

#Login to the Barracuda Load Balancer ADC
$API->login("<USERNAME>", "<PASSWORD>"); #Enter login information here
my $result;

# Listing a Resource
print "Listing Resources\n";
# Listing Virtual Services
print "Listing Virtual Services\n";
$result = $API->list('virtual_services', { virtual_service_group_id => 'default' });
print Dumper($result);
# Listing a Resource
print "Listing Resources\n";
# Listing Virtual Services
print "Listing Virtual Services\n";
$result = $API->list('virtual_services', { virtual_service_group_id => 'default' });
print Dumper($result);

# Listing Servers
print "Listing Servers\n";
$result = $API->list('servers', { virtual_service_group_id => 'default', virtual_service_id => "v6test"});
print Dumper($result);

# Listing Content Rules
print "Listing Content Rules\n";
$result = $API->list('content_rules', { virtual_service_group_id => 'default',  virtual_service_id => "v6test"});
print Dumper($result);

# Listing Monitor Groups
print "Listing Monitor Groups\n";
$result = $API->list('monitor_groups');
print Dumper($result);

# Listing Monitors
print "Listing Monitors\n";
$result = $API->list('monitors', { monitor_group_id => "MS_IIS App Pool Monitor"});
print Dumper($result);

# Listing Servers
print "Listing Servers\n";
$result = $API->list('servers', { virtual_service_group_id => 'default', virtual_service_id => "v6test"});
print Dumper($result);

# Listing Content Rules
print "Listing Content Rules\n";
$result = $API->list('content_rules', { virtual_service_group_id => 'default',  virtual_service_id => "v6test"});
print Dumper($result);

# Listing Monitor Groups
print "Listing Monitor Groups\n";
$result = $API->list('monitor_groups');
print Dumper($result);

# Listing Monitors
print "Listing Monitors\n";
$result = $API->list('monitors', { monitor_group_id => "MS_IIS App Pool Monitor"});
print Dumper($result);


use Barracuda::Rest::API;
use Data::Dumper;

# Initialize your environment
my $API = Barracuda::Rest::API->new('specify_unit_ip', '8000', 'v2', 'http', 'no');

# Require user to login at initial step
$API->login('admin', 'admin');

#Creating Resources
print "Creating Resources\n";

my $result;
$result = $API->create("certificates", undef, 
                        { 
                          name => "script_test", 
                          type => "pem",
                          signed_certificate => "/home/minh/Documents/ADC/cert/valid/server.crt",
                          assign_associated_key => "0",
                          key => "/home/minh/Documents/ADC/cert/valid/server.key",
                          allow_private_key_export => "1",
                          "intermediary_certificate_0" => "/home/minh/Documents/ADC/cert/valid/server.crt",
                          "intermediary_certificate_1" => "/home/minh/Documents/ADC/cert/valid/server.crt"
                        }, 
                        { upload => "signed"} 
                      );

print "Returned result: ".Dumper($result);

$result = $API->create('certificates', undef,
                      {
                        name => "script_test_trusted",
                        trusted_certificate => "/home/minh/Documents/ADC/cert/valid/server.crt"
                      },
                      { upload => "trusted"} );

print "Trusted Cert result: ".Dumper($result);

$result = $API->create('certificates', undef,
                      {
                        'name' => "generated_script",
                        'common_name' => "www.script.com",
                        'country_code' => 'us',
                        'state' => 'ca',
                        'city' => 'campbell',
                        'organization_name' => 'barracuda',
                        'organization_unit' => 'engineering',
                        'key_size' => '1024',
                        'allow_private_key_export' => 1 
                      });

print "Generated Certificate: ".Dumper($result);
